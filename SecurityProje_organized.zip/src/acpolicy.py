# acpolicy.py
# System security project fall 24/25
# Dr. Jassim Aljuraidan
# Students: Ghezlan Alotaibi and Maryam Matar

from pydoc import locate


class AccessControlPolicy:
    """Define an interface for an Access Control policy and static
       methods to create policy objects from definition files."""

    def is_allowed(self, subject, object, access):
        """Determine if the given access event is allowed by the policy"""

        return False

    @staticmethod
    def load_policy_from_file(filename):
        """" Create Policy object from file

        Reads a policy definition file and create the corresponding
        AccessControlPolicy object"""

        try:
            with open(filename) as file:
                policy_type = file.readline()

                if policy_type.strip().lower() == 'biba':
                    return locate("Biba.BibaPolicy").load(file)

                # TODO: add more if statements for your own policies
                elif policy_type.strip().lower() == 'belllapadula':
                    return locate("BellLaPadula.BellLaPadulaPolicy").load(file)

                elif policy_type.strip().lower() == 'ring':
                    return locate("Ring.RingPolicy").load(file)


        except OSError as e:
            print(f"{type(e)}: {e}")

        return None
