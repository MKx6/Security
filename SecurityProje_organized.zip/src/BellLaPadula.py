# System security project fall 24/25
# Dr. Jassim Aljuraidan
# Students: Ghezlan Alotaibi and Maryam Matar
import acpolicy

class BellLaPadulaPolicy(acpolicy.AccessControlPolicy):
    clearance_level = dict()
    all_categories = set()

    class Label:
        """Encapsulate a security label"""

        def __init__(self, clearance: str, categories: set[str]):
            if not (categories <= BellLaPadulaPolicy.all_categories):
                raise ValueError("Not a valid label.")

            self.clearance: str = clearance
            self.categories: set = categories

        def dominate(self, other):
            """Check if this label dominates the other label"""
            val1 = BellLaPadulaPolicy.clearance_level[self.clearance]
            val2 = BellLaPadulaPolicy.clearance_level[other.clearance]

            return val1 >= val2 and self.categories >= other.categories

    @staticmethod
    def load(file):
        return BellLaPadulaPolicy(file)

    def __init__(self, file):
        self.subject_labels = {}
        self.object_labels = {}

        value = 0
        for level in file.readline().split():
            BellLaPadulaPolicy.clearance_level[level] = value
            value += 1

        BellLaPadulaPolicy.all_categories = set(file.readline().split())

        n = int(file.readline())
        for _ in range(n):
            line = file.readline().split()
            subject = line[0]
            level = line[1]
            cats = set(line[2:])
            self.subject_labels[subject] = BellLaPadulaPolicy.Label(level, cats)

        m = int(file.readline())
        for _ in range(m):
            line = file.readline().split()
            object_ = line[0]
            level = line[1]
            cats = set(line[2:])
            self.object_labels[object_] = BellLaPadulaPolicy.Label(level, cats)

    def is_allowed(self, subject, object, access: str):
        obj_label = self.object_labels[object]
        sbj_label = self.subject_labels[subject]
        if access == "Read":
            return sbj_label.dominate(obj_label)
        elif access == "Write":
            return obj_label.dominate(sbj_label)
        elif access == "ReadAndWrite":
            return sbj_label.dominate(obj_label) and obj_label.dominate(sbj_label)
        return False

