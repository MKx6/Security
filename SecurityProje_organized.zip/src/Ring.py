# Ring.py
# System security project fall 24/25
# Dr. Jassim Aljuraidan
# Students: Ghezlan Alotaibi and Maryam Matar

import acpolicy

class RingPolicy(acpolicy.AccessControlPolicy):
    """Implement the Ring integrity policy with
    labels that consist of a level and a set
    of categories."""
    clearance_level = dict()
    all_categories = set()

    class Label:
        """Encapsulate an integrity label

        Each label is a level and a set of categories."""

        def __init__(self, clearance: str, categories: set[str]):
            if not (categories <= RingPolicy.all_categories):
                raise ValueError("Not a valid label.")

            self.clearance: str = clearance
            self.categories: set = categories

    @staticmethod
    def load(file):
        return RingPolicy(file)

    def __init__(self, file):
        self.subject_labels = {}
        self.object_labels = {}


        value = 0
        for level in file.readline().split():
            RingPolicy.clearance_level[level] = value
            value = value + 1


        RingPolicy.all_categories = set(file.readline().split())


        n = int(file.readline())
        for i in range(n):
            line = file.readline().split()
            subject = line[0]
            level = line[1]
            cats = set(line[2:])
            self.subject_labels[subject] = RingPolicy.Label(level, cats)


        m = int(file.readline())
        for i in range(m):
            line = file.readline().split()
            object = line[0]
            level = line[1]
            cats = set(line[2:])
            self.object_labels[object] = RingPolicy.Label(level, cats)

    def is_allowed(self, subject, object, access: str):
        """Check if access is allowed based on the Ring policy."""
        obj_label = self.object_labels[object]
        sbj_label = self.subject_labels[subject]

        if access == "Write":
            allowed = (
                RingPolicy.clearance_level[obj_label.clearance]
                <= RingPolicy.clearance_level[sbj_label.clearance]
            )
        elif access == "Read":
            allowed = True
        else:
            allowed = False
        return allowed
