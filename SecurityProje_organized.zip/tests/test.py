# test.py to test bellalapadula
# System security project fall 24/25
# Dr. Jassim Aljuraidan
# Students: Ghezlan Alotaibi and Maryam Matar
import acpolicy as acp


def main():
    policy = acp.AccessControlPolicy.load_policy_from_file("BellLaPadula.policy") # for biba change the file
    if not policy:
        print("Error. Could not read policy")
        exit()

    with open("example1.events") as file:
        line = file.readline()
        while line:
            line = line.split()
            subject = line[0]
            objectName = line[1]
            access = line[2]
            if policy.is_allowed(subject, objectName, access):
                allowed_str = "allowed"
            else:
                allowed_str = "not allowed"
            print(f"{subject} {access} {objectName} -> is {allowed_str}.")

            line = file.readline()


if __name__ == "__main__":
    main()
